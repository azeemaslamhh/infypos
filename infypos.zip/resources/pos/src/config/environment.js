export const environment = {
    URL: window.location.protocol + '//' + window.location.hostname,
};
